#!/usr/bin/python

# Copyright: (c) Arenadata Software LLC, 2025
# www.arenadata.tech
# Written by Vladimir Bogdanov based on Pavel Prokopov's deb_pkg_check


"""
Ansible module for check package in RPM-based distributions
"""


import os
import re

from ansible.module_utils.basic import AnsibleModule

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = '''
---
module: rpm_pkg_check

short_description: Ansible module for check package in RPM-based distributions

version_added: "2.9"

description:
    - "Ansible module for check package in RHEL, CentOS, RedOS, Rocky Linux, etc."

options:
    pkg:
        description:
            - format: <pkg_name>[-<pkg_version>[-<pkg_release>]]
        required: true
        type: string
        aliases:
            - name
            - package
    check:
        description:
            - kind of check
        choices:
            - available
            - installed
        type: string
        required: true
        aliases: test
    update_cache:
        description:
            - update dnf/yum cache
            - only for check available
            - mutually exclusive with C(clean_cache)
        type: bool
        default: false
        aliases: update-cache
    clean_cache:
        description:
            - clean dnf/yum cache
            - only for check available
            - mutually exclusive with C(update_cache)
        type: bool
        default: false
        aliases: clean-cache
    dir_repo:
        description:
            - options for yum/dnf: --setopt=reposdir=
            - only for check available
        type: string
        required: false
        aliases: etc
    dir_cache
        description:
            - options for yum/dnf: --setopt=cachedir=
            - only for check available
        type: string
        required: false
        aliases: cache

author:
    - Vladimir Bogdanov (based on Pavel Prokopov's work)
'''

EXAMPLES = '''
# Test availability
- name: Test1 availability
  rpm_pkg_check:
    pkg: '{{ item }}'
    check: 'available'
    update-cache: true
    clean-cache: true
    dir_repo: "/tmp/ansible.GI1E1v/yum.repos.d"
    dir_cache: "/tmp/ansible.5EZsaz"
  loop:
    - 'vim-8.2.2637-20.el9_1'
    - 'vim-8.2.2637'
    - 'vim'

- name: Test2 availability
  rpm_pkg_check:
    pkg: 'tar'
    check: 'available'

# Test installed
- name: Test1 installed
  rpm_pkg_check:
    pkg: '{{ item }}'
    check: 'installed'
  loop:
    - 'vim-8.2.2637-20.el9_1'
    - 'vim-8.2.2637'
    - 'vim'
'''

RETURN = '''
# Test installed good
installed: true
versions: [
    {
        "release": "20.el9_1",
        "version": "8.2.2637",
        "arch": "x86_64",
        "epoch": "2"
    }
]

# Test installed bad
installed: false
versions: null

# Test availability good
available: true
versions: [
    {
        "release": "20.el9_1",
        "version": "8.2.2637",
        "arch": "x86_64",
        "epoch": "2"
    },
    {
        "release": "16.el9",
        "version": "8.2.2637",
        "arch": "x86_64",
        "epoch": "2"
    }
]

# Test availability bad
available: false
versions: null
'''


DNF = '/usr/bin/dnf'
YUM = '/usr/bin/yum'
RPM = '/usr/bin/rpm'


class PkgCheck(AnsibleModule):
    '''
    Class for check packages in RPM-based distributions
    '''

    def __init__(self):
        self.result = dict(
            changed=False
        )

        modules_args = dict(
            pkg=dict(type='str', required=True, aliases=['name', 'package']),
            update_cache=dict(type='bool', default=False, aliases=['update-cache']),
            clean_cache=dict(type='bool', default=False, aliases=['clean-cache']),
            check=dict(type='str', required=True, aliases=['test'],
                       choices=['available', 'installed']),
            dir_repo=dict(type='str', required=False, aliases=['repo']),
            dir_cache=dict(type='str', required=False, aliases=['cache'])
        )

        super(PkgCheck, self).__init__(argument_spec=modules_args, supports_check_mode=False)

        # Prefer dnf over yum
        if os.path.exists(DNF):
            self.pkg_mgr = DNF
        elif os.path.exists(YUM):
            self.pkg_mgr = YUM
        else:
            self.fail_json(msg='cannot find dnf or yum')

        if not os.path.exists(RPM):
            self.fail_json(msg='cannot find %s' % RPM)

        for opt_dir in ['dir_repo', 'dir_cache']:
            if self.params[opt_dir]:
                if self.params['check'] != 'available':
                    self.fail_json(msg='bad option: %s' % opt_dir, **self.result)
                if not os.path.isdir(self.params[opt_dir]):
                    self.fail_json(msg='%s is not dir: %s'
                                   % (opt_dir, self.params[opt_dir]),
                                   **self.result)

    def build_cmd_options(self):
        '''
        Build common dnf/yum options
        '''

        opt = ""
        if self.params['dir_repo']:
            opt = opt + " --setopt=reposdir=" + self.params['dir_repo']
        if self.params['dir_cache']:
            opt = opt + " --setopt=cachedir=" + self.params['dir_cache']
        return opt

    def update_package_db(self):
        '''
        yum/dnf check-update
        '''

        opt = self.build_cmd_options()
        cmd = "%s %s check-update -q" % (self.pkg_mgr, opt)
        ret, out, err = self.run_command(cmd)

        error = dict(
            cmd=cmd,
            rc=ret,
            stderr=err,
            stdout=out
        )

        # RC 100 means updates are available, which is normal
        # RC 0 means no updates available
        if ret not in [0, 100]:
            self.fail_json(msg="could not update package db", **error)

    def clean_cache(self):
        '''
        yum/dnf clean all
        '''

        opt = self.build_cmd_options()
        cmd = "%s %s clean all -q" % (self.pkg_mgr, opt)

        ret, out, err = self.run_command(cmd)

        error = dict(
            cmd=cmd,
            rc=ret,
            stderr=err,
            stdout=out
        )

        if ret != 0:
            self.fail_json(msg="could not clean cache", **error)

    def parse_pkg(self):
        '''
        parse package name string
        '''

        pkg = self.params['pkg']
        # pkg: '<name>[[=<version>]-<release>][.<arch>]'
        # Extract architecture if present
        # https://regex101.com/r/DFfBP1/1
        arch_match = re.match(r'^(?P<base>.+?)\.(?P<arch>noarch|x86_64|i686)$', pkg)

        if arch_match:
            # Architecture found, parse the base part
            base_pkg = arch_match.group('base')
            arch = arch_match.group('arch')
        else:
            base_pkg = pkg
            arch = ""

        # Parse name-version-release from base_pkg
        # Version must contain either a dot or underscore to distinguish from name parts
        # https://regex101.com/r/Uh5T11/1
        match = re.match(r"^(?P<name>.+?)(?:-(?P<version>\d+(?:\.\d+)+(?:[a-z])?(?:_\w+)?|\d+[a-z]?_\w+)(?:-(?P<release>.+))?)?$", base_pkg)

        if match is None:
            self.fail_json(msg="Bad format of pkg: '%s'" % pkg, **self.result)

        result = match.groupdict("")
        result['arch'] = arch

        return result

    def get_installed_versions(self, pkg_name):
        '''
        get installed package version using rpm
        '''

        # rpm -q --queryformat for installed packages
        # example if epoch doesn't exist: (none):5.2.15-1.el7 x86_64
        cmd = "%s -q --queryformat='%%{NAME} %%{EPOCH}:%%{VERSION}-%%{RELEASE} %%{ARCH}\\n' %s" % (RPM, pkg_name)
        ret, out, err = self.run_command(cmd)

        if ret != 0:
            error = dict(
                cmd=cmd,
                rc=ret,
                stderr=err,
                stdout=out
            )
            self.result['error'] = error
            return None

        versions = []
        # Parse output: name epoch:version-release arch
        for line in out.strip().split('\n'):
            if not line:
                continue
            # Example: vim 2:8.2.2637-20.el9_1 x86_64
            # https://regex101.com/r/rAasXj/1
            match = re.match(
                r'^' + re.escape(pkg_name) +
                r'\s+(?P<epoch>[^:]+):(?P<version>[^-]+)-(?P<release>\S+)\s+(?P<arch>\S+)$',
                line.strip()
            )
            if match:
                ver_dict = match.groupdict()
                # Clean epoch if it's (none) (standard RPM behavior)
                if ver_dict['epoch'] == '(none)':
                    ver_dict['epoch'] = '0'
                versions.append(ver_dict)

        return versions if versions else None

    def get_available_versions(self, pkg_name):
        '''
        get available package versions using dnf/yum
        '''

        opt = self.build_cmd_options()
        # Use --showduplicates to get all available versions
        cmd = "%s %s list available %s -q --showduplicates" % (self.pkg_mgr, opt, pkg_name)
        ret, out, err = self.run_command(cmd)

        if ret != 0:
            error = dict(
                cmd=cmd,
                rc=ret,
                stderr=err,
                stdout=out
            )
            self.result['error'] = error
            return None

        versions = []
        # Parse list output
        # Format: name.arch  [epoch:]version-release  repo
        # Example with epoch: vim-enhanced.x86_64  2:8.2.2637-20.el9_1  baseos
        # Example without epoch: tmux.x86_64  3.5a-2.el7  updates
        for line in out.strip().split('\n'):
            if not line or line.startswith('Available') or line.startswith('Last metadata'):
                continue

            parts = line.split()
            if len(parts) < 2:
                continue

            # Parse name.arch
            name_arch = parts[0].rsplit('.', 1)
            if len(name_arch) != 2:
                continue

            name = name_arch[0]
            arch = name_arch[1]

            # Check if name matches (handle variations like vim-enhanced for vim and skip neovim)
            if not name.startswith(pkg_name):
                continue

            # Parse [epoch:]version-release
            evr = parts[1]
            # Match with optional epoch
            # https://regex101.com/r/Br3oD7/1
            match = re.match(r'^(?:(?P<epoch>[^:]+):)?(?P<version>[^-]+)-(?P<release>.+)$', evr)
            if match:
                ver_dict = match.groupdict()
                ver_dict['arch'] = arch
                # Clean epoch if it's (none) (standard RPM behavior)
                if ver_dict['epoch'] is None:
                    ver_dict['epoch'] = '0'
                versions.append(ver_dict)

        return versions if versions else None

    def check_pkg(self, check):
        '''
        check package
        '''

        def ret_status(status):
            self.result[check] = status
            self.exit_json(**self.result)

        pkg = self.parse_pkg()

        if check == "available":
            versions = self.get_available_versions(pkg['name'])
        elif check == "installed":
            versions = self.get_installed_versions(pkg['name'])

        self.result['versions'] = versions

        if versions is None:
            ret_status(False)

        # If no specific version requested, just check if package exists
        if len(versions) > 0 and (pkg['version'] is None or pkg['version'] == ""):
            ret_status(True)

        # Check for matching version
        for ver in versions:
            if pkg['version'] == ver['version']:
                # If no release specified, match on version only
                if pkg['release'] is None or pkg['release'] == "" or pkg['release'] == ver['release']:
                    ret_status(True)

        ret_status(False)

    def run(self):
        '''
        run
        '''

        if self.params['update_cache']:
            if self.params['check'] != 'available':
                self.fail_json(msg='bad option, update_cache only for check available',
                               **self.result)
            self.update_package_db()

        if self.params['clean_cache']:
            if self.params['check'] != 'available':
                self.fail_json(msg='bad option, clean_cache only for check available',
                               **self.result)
            self.clean_cache()

        self.check_pkg(self.params['check'])


def main():
    """
    Main function that runs the module
    """

    PkgCheck().run()


if __name__ == '__main__':
    main()
